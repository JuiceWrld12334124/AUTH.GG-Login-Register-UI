﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Auth;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Diagnostics;
// Zelfde hier mouse events voor het draggen van de forms.
// Het enigste hier is de Click event voor iconpicture, dat is het pijltje die terug gaat naar de login-scherm als je terug wilt.
namespace UISpoofer
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }
        //definities
        bool mouseDown;
        private Point Offset;
        public bool Response { get; set; } //horrible but working system to switch between redeem and register
        //_________________________________\\

        //mouse events picturebox4
        private void pictureBox4_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;

        }
        //---------------------------------\\
        private void pictureBox4_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown == true)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new Point(currentScreenPos.X - Offset.X, currentScreenPos.Y - Offset.Y);
            }

        }
        //---------------------------------\\
        private void pictureBox4_MouseDown(object sender, MouseEventArgs e)
        {
            Offset.X = e.X;
            Offset.Y = e.Y;
            mouseDown = true;

        }
        //_________________________________\\

        //Mouse events panel1
        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;

        }
        //---------------------------------\\
        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {

            if (mouseDown == true)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new Point(currentScreenPos.X - Offset.X, currentScreenPos.Y - Offset.Y);
            }

        }
        //---------------------------------\\
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            Offset.X = e.X;
            Offset.Y = e.Y;
            mouseDown = true;

        }
        //_________________________________\\

        //Click events
        private void iconPictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login frm = new Login();
            frm.Show();
        }
        //_________________________________\\

        //Empty functions
        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12; //bugs sometimes
            if (Redeem.Checked)
            {
                //The redeem arguments goes in the order: username, password, token
                Response = Handler.RedeemToken(textBox1.Text, textBox2.Text, textBox3.Text); //redeem a token using textboxes
            }
            else
            {
                // The register arguments goes in the order: username, password, email, token
                Response = Handler.Register(textBox1.Text, textBox2.Text, textBox4.Text, textBox3.Text); //register using textboxes
            }
            if (Response)
            {
                Handler.Log(textBox1.Text, "registered/redeemed succefuly");
            }
            else
            {

            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        //_________________________________\\


    }
}
