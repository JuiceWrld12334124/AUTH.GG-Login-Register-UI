﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace UISpoofer
{
    public partial class Form2 : Form
    {


        public Form2()
        {
            InitializeComponent();
            Progressbar.Value = 0;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }



        private void Progressbar_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            Progressbar.Value += 1;
            Progressbar.Text = Progressbar.Value.ToString() + "%";

            if (Progressbar.Value == 100)
            {
                timer1.Enabled = false;
                UI frm = new UI();
                this.Hide();
                frm.Show();

            }

        }
    }
}
