﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Auth;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Diagnostics;
// Mouse events zijn voor het draggen van alle forms die nodig zijn. Ze zijn gezet op alle delen van de UI waar de user aan kan bewegen
// Click events zijn gemaakt om naar de volgende Form te gaan.
namespace UISpoofer
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            Auth.Handler.Initialize();
        }
        //Definities -------------
        bool mouseDown;
        private Point Offset;
        //------------------------\\

        //Mouse Events pictureBox3
        private void pictureBox3_MouseDown(object sender, MouseEventArgs e)
        {
            Offset.X = e.X;
            Offset.Y = e.Y;
            mouseDown = true;
        }
        //------------------------\\
        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown == true)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new Point(currentScreenPos.X - Offset.X, currentScreenPos.Y - Offset.Y);
            }
        }
        //------------------------\\
        private void pictureBox3_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        //_________________________________\\

        //Mouse events Panel1
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            Offset.X = e.X;
            Offset.Y = e.Y;
            mouseDown = true;

        }
        //------------------------\\
        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }
        //------------------------\\
        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown == true)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new Point(currentScreenPos.X - Offset.X, currentScreenPos.Y - Offset.Y);
            }

        }
        //_________________________________\\

        //Click Events
        private void button1_Click(object sender, EventArgs e)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12; //bugs sometimes
            bool response = Handler.Login(textBox1.Text, textBox2.Text); //login using the first and the second textbox, there is a third argument that disables the auth.gg login messages
            if (response)
            {
                Handler.Log(textBox1.Text, "Succesfully logged in!");
                UI form = new UI(); //create a new main form
                this.Hide(); //hide this form
                form.Show(); //open the new main form

            }


        }
        //---------------------------------\\
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Register frm = new Register();
            frm.Show();
        }
        //_________________________________\\

        //Empty Functions
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        //---------------------------------\\
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //---------------------------------\\
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        //---------------------------------\\
        private void Login_Load(object sender, EventArgs e)
        {

        }
        //---------------------------------\\
        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }
        //_________________________________\\
    }
}
