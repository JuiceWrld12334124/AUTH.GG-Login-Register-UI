﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace UISpoofer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //definities
        bool mouseDown;
        private Point Offset;

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            UI frm = new UI();
            frm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.youtube.com/watch?v=KttfFK8ZBRg");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://discord.gg/fm674pdWgX");
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            Offset.X = e.X;
            Offset.Y = e.Y;
            mouseDown = true;

        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown == true)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new Point(currentScreenPos.X - Offset.X, currentScreenPos.Y - Offset.Y);
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            Offset.X = e.X;
            Offset.Y = e.Y;
            mouseDown = true;

        }

        private void panel2_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown == true)
            {
                Point currentScreenPos = PointToScreen(e.Location);
                Location = new Point(currentScreenPos.X - Offset.X, currentScreenPos.Y - Offset.Y);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
